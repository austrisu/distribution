package App::Cilly::CilConfig;

$::cc        = "gcc";
$::default_mode = "GNUCC";
